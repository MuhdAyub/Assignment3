package com.example.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etAmount;
    TextView tvPercent;
    SeekBar sbPercent;
    TextView tvTipAmount;
    TextView tvTotalAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etAmount = findViewById(R.id.etAmount);
        tvPercent=findViewById(R.id.tvPercent);
        sbPercent=findViewById(R.id.sbPercent);
        tvTipAmount=findViewById(R.id.tvTipAmount);
        tvTotalAmount=findViewById(R.id.tvTotalAmount);

        sbPercent.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                int percent =progress;
                tvPercent.setText(String.valueOf(percent)+"%");
                calculate();


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        etAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                calculate();

            }
        });
    }

    private void    calculate(){
        if(etAmount.length()==0){
            etAmount.setError("Enter Amount");

        }else{
            double Amount=Double.parseDouble(etAmount.getText().toString());
            int percent =sbPercent.getProgress();
            double Tip= Amount*percent/100.0;
            double Total= Amount +Tip;
            tvTipAmount.setText(String.valueOf(Tip));
            tvTotalAmount.setText(String.valueOf(Total));


        }
    }
        }